
package terminalPM;

@SuppressWarnings("serial")
public class DeadException extends Exception {

	public DeadException() {}

}
